## Techglobal School Training - Server
Techglobal School Training - Server is a RESTful API Application built with Node.js and Express. It's used to control API/db of *Backend Testing* in [Techglobal School Training App](https://techglobal-training.com/backend).

### Deployment

-   TBD

Scripts:

-   TBD

### Contributors

[Altay Ozyavas](https://github.com/altayozyavas) |
[Burak Simsek](https://github.com/buraksimsekgit) |
[Ulan Rakymzhan](https://github.com/urakymzhan)